# interactive-map-of-Pennsylvania_Aidan-project
This project showcases an interactive map of Pennsylvania, focusing on key data for each county, including:  County Names: Displays the names of all counties in Pennsylvania. Land Area: Shows the land area for each county (in square miles or kilometers). Population: Provides population data for each county.
